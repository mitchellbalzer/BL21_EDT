#!/bin/sh

set -x

SCRPT_BASENAME=${0##*/}
SCRPT_CALL=$0
SCRPT_NAME=`readlink -f $0`

CURDIR=`pwd`
LZMA_CMD=lzma
LZMA_ALTCMD=

# check if this is a pre 2.1 installation (pre 3. on c2100, i.e. topcon)
which $LZMA_CMD 2>&1 > /dev/null
if [ "$?" = "0" ] ; then
	# tool exists, busybox version > 1.11.x
	VERSION_COMPATIBLE_FLAG=-c
else
	VERSION_COMPATIBLE_FLAG=
	LZMA_CMD=
fi

INSTALLER_TMP_DIR=/tmp/install
PRPRE_INSTALL=no
FORCE_UNATTENDED_INSTALL=
UNATTENDED_OPT=
LOADER_FLAG=
SYSTEM_FLAG=





if [ $# -eq 2 ] ; then 
	exit 2
fi
# get the CONSOLE_MODEL (for now either c1000 or c2100)
CONSOLE_MODEL=notset
PROC_INFO=`cat /proc/cpuinfo | grep 'cpu' | awk {'print $3'}`

if  [ "e300c4" = "$PROC_INFO" ] || [ "G2_LE" = "$PROC_INFO" ]  ; then 
	CONSOLE_MODEL=c1000 
	BOOTSOURCE=/dev/mtdblock1
else 
	CONSOLE_MODEL=c2100 
	CF_PARTITION_RFS=/dev/hda7
	CF_PARTITION_OPT=/dev/hda5
	BOOTSOURCE=$CF_PARTITION_RFS
fi

if [ "$CONSOLE_MODEL" = "c1000" ] ; then 
	# dont allow installation from usb2 
	VALID_INSTALLATION_MEDIA="usb1 sdcard sdcard1"
else
	VALID_INSTALLATION_MEDIA="usb1 usb2"
fi

# check from which media installation was started
for m in $VALID_INSTALLATION_MEDIA ; do
	if [ "${SCRPT_NAME}" != "${SCRPT_NAME/$m}" ] ; then
		MEDIA_SOURCE=/mnt/$m
	fi
done


if [ "$MEDIA_SOURCE" = "" ] ; then
	echo "installation can only be started from usb or sdcard removable media "
	exit 1
fi 

# check boot source
cat /proc/cmdline | grep $BOOTSOURCE 2>&1 > /dev/null

if [ "$?" = "0" ] ; then 
	# not booting from RAM, so it must be an AGCO installation old or new software,
	# the -r tells installer to update a recent AGCO BSP version 
	INSTALLER_MODE=update
	SYSTEM_FLAG=-r
else
	INSTALLER_MODE=recovery
	SYSTEM_FLAG=
	# booting from usb, for c2100 it must be a transition from a topcon to agco BSP via USB boot
	if [ "$CONSOLE_MODEL" = "c2100" ]; then
		VERSION_COMPATIBLE_FLAG=
	fi
fi

# If software installer already running, don't restart it
#ps | grep SIcore_[0]	#trick to ignore the grep process
LIST_OF_PS=`ps`
echo $LIST_OF_PS | grep SIcore_c
if [ "$?" = "0" ] ; then exit 0 ; fi

# check for memory
MEMFREE=`cat /proc/meminfo | grep 'MemFree' | awk {'print $2'}`
TOTAL=`du -s -k -x / | awk {'print $1'}`
if [ "$CONSOLE_MODEL" = "c1000" ]; then
	# use 59 MB max NOR file system
	TOTAL=$(($TOTAL + 60416))
else
	# c2100 allow 70 MB
	TOTAL=$(($TOTAL + 71680))
fi
echo "need approx. $TOTAL KB for installations temp buffer"
if [ $MEMFREE -ge $TOTAL ] ; then
	TOTAL=$(($MEMFREE - $TOTAL))
else
	TOTAL=0
fi
echo "space left for runtime copies $TOTAL KB..."
# guess we will need about 10 MB additional RAM to be able to do 
# an installation w/o going to recovery mode
if [ $TOTAL -ge 3000 ] ; then
	echo "enough memory for installation available"
else
	echo "not enough memory for installation"
	exit 1
fi

# remove potential artefact from unsuccessful earlier runs
if [ -f /tmp/install.log ] ; then
	rm -f /tmp/install.log
fi
if [ -f /tmp/install_mediacopy_failed ] ; then
	rm -f /tmp/install_mediacopy_failed
fi
if [ -d /tmp/install ] ; then
	rm -rf /tmp/install
fi
if [ "no" = "$PRPRE_INSTALL" ] ; then 
	# check for previous installation
	query-sram_$CONSOLE_MODEL -i 2> /dev/null
	if [ "$?" = "1" ] ; then query-sram_$CONSOLE_MODEL -r ; exit 0 ; fi
fi

echo "extracting files from $MEDIA_SOURCE/$CONSOLE_MODEL ..."

# get a directory for installer specific files
mkdir -p $INSTALLER_TMP_DIR/$CONSOLE_MODEL
TAG_CAN_START_FILE=$INSTALLER_TMP_DIR/$CONSOLE_MODEL/install_prep
if [ -f $TAG_CAN_START_FILE ] ; then rm -f $TAG_CAN_START_FILE ; fi

if [ "$LZMA_CMD" = "" ] ; then 
	LZMA_DECODER=lzmadec_${CONSOLE_MODEL}
	LZMA_ARCHIVE=$MEDIA_SOURCE/$CONSOLE_MODEL/${LZMA_DECODER}.gz
	if [ -f $LZMA_ARCHIVE ] ; then
		mkdir /tmp/${LZMA_DECODER}
		cd /tmp/${LZMA_DECODER} 
		cp $LZMA_ARCHIVE /tmp/${LZMA_DECODER}/
		gunzip /tmp/${LZMA_DECODER}/${LZMA_DECODER}.gz
		LZMA_ALTCMD="/tmp/${LZMA_DECODER}/${LZMA_DECODER}"
		cd $CURDIR
	fi
fi


# start to extract installer content to /tmp
# 3.cpio contains the agco configuration scripts and settings
# 10.cpio contains the content to be moved to the xtra-partition
# 11.cpio contains SI_core and SI executables (the gui and the runtime of the installer)

# copy rebranding information to installer temp dir 
if [ -f "$MEDIA_SOURCE/$CONSOLE_MODEL/terminalid.xml" ] ; then cp "$MEDIA_SOURCE/$CONSOLE_MODEL/terminalid.xml" $INSTALLER_TMP_DIR/$CONSOLE_MODEL/ ; fi

# copy rebranding information to installer temp dir 
if [ -d "$MEDIA_SOURCE/$CONSOLE_MODEL/vrtddi" ] ; then cp -R "$MEDIA_SOURCE/$CONSOLE_MODEL/vrtddi" $INSTALLER_TMP_DIR/$CONSOLE_MODEL/ ; fi

NEEDED_CPIO="11 3"
cd $INSTALLER_TMP_DIR/$CONSOLE_MODEL
for ce in $NEEDED_CPIO ; do
	if [ ! "${LZMA_CMD}" = "" ] ; then
		${LZMA_CMD} -d -c $MEDIA_SOURCE/$CONSOLE_MODEL/$ce.cpio.lzma | cpio -iu  2>&1 > /dev/null 
		if [ ! "$?" = "0" ] ; then
			echo "failed to extract $MEDIA_SOURCE/$CONSOLE_MODEL/${ce}.cpio.lzma, abort ..." 
			exit 1
		fi
	else
		cat $MEDIA_SOURCE/$CONSOLE_MODEL/$ce.cpio.lzma | ${LZMA_ALTCMD} | cpio -iu  2>&1 > /dev/null 
		if [ ! "$?" = "0" ] ; then
			# error 
			echo "failed to extract $MEDIA_SOURCE/$CONSOLE_MODEL/${ce}.cpio.lzma, abort ..." 
			exit 1
		fi
	fi
done
cd $CURDIR

# TARGET_DIR
# SOURCE_DIR=$MEDIA_SOURCE/$CONSOLE_MODEL
export LZMA_ALTCMD LZMA_CMD TAG_CAN_START_FILE MEDIA_SOURCE INSTALLER_TMP_DIR PRPRE_INSTALL FORCE_UNATTENDED_INSTALL UNATTENDED_OPT LOADER_FLAG SYSTEM_FLAG VERSION_COMPATIBLE_FLAG INSTALLER_MODE CONSOLE_MODEL


# preprfs.sh is contained in 3.cpio
$INSTALLER_TMP_DIR/$CONSOLE_MODEL/setup/preprfs.sh 2>&1 > /tmp/install.log &



