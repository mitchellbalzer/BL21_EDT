#!/bin/sh

SOURCE_FW_DIR=$1

cat /proc/cmdline | grep "prep_fwupd" > /dev/null
if [ "$?" = "0" ] ; then INITFWUPDATE=1;  fi

if [ "1" = "$INITFWUPDATE" ] ; then

	# this is the required first reboot after software bundle was installed
	
	# modify bootloader
	mkdir -p /tmp/boot
	mount /dev/hda1 /tmp/boot
	mount -o remount,rw /tmp/boot
	# next boot should boot into TopCons firmware installer
	sed -i  '/kernel /d'  /tmp/boot/grub/menu.lst
	
	echo 'kernel /ubnkern clocksource=hpet hpet=verbose nmi_watchdog=panic nmi_watchdog=lapic console=tty2 video=1024x768-32 vga=0x318 looproot=/dev/hda8:image.ext2 rootdelay=6 root=/dev/loop pwrcntx30 ' >> /tmp/boot/grub/menu.lst

	sync
	umount /tmp/boot
	
else
	# this is called at the end of software update (prep_fwupd keyword not contained in kernel cmd line)

	FIRMWARE_FOLDER=$SOURCE_FW_DIR/firmware

#	if [ -d $FIRMWARE_FOLDER ] && [ -f $FIRMWARE_FOLDER/syslinux.cfg ] ; then
	if [ -d $FIRMWARE_FOLDER ] ; then

		# folder might contain multiple hex files, the one to be process is X30PM*.hex
		if [ -f $FIRMWARE_FOLDER/X30PM*.hex ] ; then

			diff $FIRMWARE_FOLDER/X30PM*.hex /data/pm/power.hex 2>/dev/null
			if [ ! "$?" = "0" ] ; then
				cp -R $FIRMWARE_FOLDER /data/
				sync
				# modify bootloader
				mkdir -p /tmp/boot
				mount /dev/hda1 /tmp/boot
				mount -o remount,rw /tmp/boot

				sed -i 's/recovery.img/recovery.img prep_fwupd/g' /tmp/boot/grub/menu.lst
				cp $FIRMWARE_FOLDER/ubnkern /tmp/boot/
				sync
				umount /tmp/boot

				# modify TopCons installed 
				mkdir -p /tmp/ext2
				mount -o loop /data/firmware/image.ext2 /tmp/ext2
	#			mv /tmp/ext2/etc/run_on_reboot_finished /tmp/ext2/etc/run_on_reboot_finished.org
	#			cp $SOURCE_FW_DIR/fwbootmenu /tmp/ext2/etc/run_on_reboot_finished
	#			cat /tmp/ext2/etc/run_on_reboot_finished.org >> /tmp/ext2/etc/run_on_reboot_finished
				sed -i "s/\/etc\/run_on_reboot_finished/\/etc\/fwbootmenu/g" /tmp/ext2/etc/init.d/remove_usb
				cp $SOURCE_FW_DIR/fwbootmenu /tmp/ext2/etc
				cp $FIRMWARE_FOLDER/X30PM* /tmp/ext2/firmware
				sync
				umount /tmp/ext2
				cp $SOURCE_FW_DIR/prep_firmware_upd.sh /data/firmware
				mv /data/firmware/image.ext2 /data
				sync
			fi
		fi
	fi
	